import torch
from torch.utils.data import DataLoader
from src.data_preprocessing.dataset import InfantVocalDataset
from src.models.efficientnet_lstm import build_model
from src.training.utils import compute_metrics
import argparse

def collate_fn(batch):
    seqs, labels = zip(*batch)
    max_s = max([s.shape[0] for s in seqs])
    B = len(seqs)
    C, H, W = seqs[0].shape[1:]
    out = torch.zeros((B, max_s, C, H, W), dtype=seqs[0].dtype)
    for i, s in enumerate(seqs):
        L = s.shape[0]
        out[i, :L] = s
        if L < max_s:
            out[i, L:] = s[-1].unsqueeze(0).repeat(max_s - L, 1, 1, 1)
    labels = torch.tensor(labels, dtype=torch.long)
    return out, labels

def evaluate(args):
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    ds = InfantVocalDataset(args.data_root)
    num_classes = len(ds.labels_map)
    model = build_model(num_classes=num_classes)
    ckpt = torch.load(args.checkpoint, map_location=device)
    model.load_state_dict(ckpt["model_state"])
    model.to(device)
    dl = DataLoader(ds, batch_size=args.batch_size, collate_fn=collate_fn, num_workers=0)
    ys, preds = [], []
    model.eval()
    with torch.no_grad():
        for x_seq, y in dl:
            x_seq = x_seq.to(device)
            logits = model(x_seq)
            p = logits.argmax(dim=1).cpu().numpy()
            ys.extend(y.numpy().tolist())
            preds.extend(p.tolist())
    metrics = compute_metrics(ys, preds)
    print("Evaluation results:", metrics)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_root", type=str, default="data/raw")
    parser.add_argument("--checkpoint", type=str, required=True)
    parser.add_argument("--batch_size", type=int, default=8)
    parser.add_argument("--device", type=str, default="cpu")
    args = parser.parse_args()
    evaluate(args)
